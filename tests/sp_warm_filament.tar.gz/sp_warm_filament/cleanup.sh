#!/bin/bash

rm RUN_CONTROL_*
rm CPU_*
rm DATA_*
rm HEADER_*
