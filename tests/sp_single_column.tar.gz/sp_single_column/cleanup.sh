#!/bin/bash

rm DATA_*
rm RUN_CONTROL_*
rm CPU_*
rm HEADER_*
